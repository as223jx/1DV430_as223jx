package com.example.receptapp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
	    if (savedInstanceState == null) {
	        getSupportFragmentManager().beginTransaction()
	                .add(R.id.container, new PlaceholderFragment())
	                .commit();
	    
 	   }
    }

	public void newRecipe(View view) {
    	Intent newRecipe = new Intent(this, NewRecipeActivity.class);
    	startActivity(newRecipe);
    }
    
   public void listRecipes() {

   }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            
            TextView viewList = (TextView) rootView.findViewById(R.id.test_list);
       	 	String fileName = "recept.txt";
            String line = "";
            try{
            	File testFile = new File(getActivity().getFilesDir() + "/" + fileName);
            	String path = testFile.getAbsolutePath();
            	System.out.println("1 " + path);
            	
            	InputStream inputStream = new FileInputStream(path);

            	InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            	BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            	StringBuilder stringBuilder = new StringBuilder();
        
            	while((line = bufferedReader.readLine()) != null){
            		stringBuilder.append(line);
            	}
            	inputStream.close();
            	String recipe = stringBuilder.toString();
            	 System.out.println(recipe);
            	try{
            	viewList.setText(recipe);
            	}
            	catch (Exception e) { System.out.println("Ok");}
            }
            catch(FileNotFoundException ex) {
            	System.out.println("Unable to open file '" + fileName + "'");
            }
            catch(IOException ex) {
            	System.out.println("Error reading file '" + fileName + "'");
            }
        	catch (NullPointerException ex){
        		System.out.println("Det gick inte s� bra '" + fileName + "'");
        	}
            
            return rootView;
        }
    }

}
