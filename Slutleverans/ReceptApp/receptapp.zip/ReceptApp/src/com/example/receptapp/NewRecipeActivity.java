package com.example.receptapp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
//import android.widget.ArrayAdapter;
//import android.widget.Spinner;

public class NewRecipeActivity extends ActionBarActivity {

	public final static String EXTRA_NAME = "com.example.receptapp.NAME";
	public final static String EXTRA_INGREDIENTS = "com.example.receptapp.INGREDIENTS";
	public final static String EXTRA_INSTRUCTIONS = "com.example.receptapp.INSTRUCTIONS";
	public final static String EXTRA_AMOUNT = "com.example.receptapp.AMOUNT";
	static int i = 0;
	public static String SPINNER = "com.example.receptapp.SPINNER";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_recipe);
		

		
//		Spinner unitSpinner = (Spinner) findViewById(R.id.unitSpinner);
//		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.units_array, android.R.layout.simple_spinner_item);
//		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//		unitSpinner.setAdapter(adapter);
		

		
		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
			}
	}
	 
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.new_recipe, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_new_recipe,
					container, false);
			
			// Skapar ny LinearLayout och l�gger in f�lt f�r ny ingrediens
			Button b = (Button) rootView.findViewById(R.id.add_ingredient);
			final LinearLayout ingredientll = (LinearLayout) rootView.findViewById(R.id.newLayout);
			final LinearLayout amountll = (LinearLayout) rootView.findViewById(R.id.amount_layout);
			final LinearLayout spinnerll = (LinearLayout) rootView.findViewById(R.id.spinnerLayout);
			final android.widget.LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			final android.widget.LinearLayout.LayoutParams amountLayoutParams = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			final android.widget.LinearLayout.LayoutParams spinnerLayoutParams = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			
			// Spinner
			Spinner spinner = (Spinner) rootView.findViewById(R.id.unitSpinner);
			ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(), R.array.units_array, android.R.layout.simple_spinner_item);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner.setAdapter(adapter);
			spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() 
            {
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) 
                {
                	String selected = parent.getItemAtPosition(pos).toString();
                	Toast.makeText(getActivity(), selected, Toast.LENGTH_SHORT).show();
                	
                	SPINNER = selected;

                }

                public void onNothingSelected(AdapterView<?> parent) 
                {

                }
            });
			
			// L�gg till ny ingrediensrad
			b.setOnClickListener(new OnClickListener(){
			
				@Override
				public void onClick(View v) {
					EditText newIngredient = new EditText(getActivity());
					EditText newAmount = new EditText(getActivity());
					Spinner newSpinner = new Spinner(getActivity());
					ArrayAdapter<String> newAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, R.array.units_array);
					newIngredient.setHint("Ange ingrediens");
					newAmount.setHint("Antal");
					newIngredient.setId(++i);
					newIngredient.setLayoutParams(layoutParams);
					newAmount.setLayoutParams(amountLayoutParams);
					newSpinner.setLayoutParams(spinnerLayoutParams);
					newSpinner.setAdapter(newAdapter);
					ingredientll.addView(newIngredient);
					amountll.addView(newAmount);
					spinnerll.addView(newSpinner);
				}
			});
			
			// Testar l�sa in receptet med namn "test.txt"
			
			Button read = (Button) rootView.findViewById(R.id.button_testSave);
			
			read.setOnClickListener(new View.OnClickListener(){
				
				public void onClick(View v) {
					
					NewRecipeActivity read = (NewRecipeActivity) getActivity();
			
					read.readFromFile("test.txt");
				}
			});
			
	
			
			return rootView;
		}
	}
	
//	public void saveRecipe(View view) {
//		Intent intent = new Intent(this, ViewRecipe.class);
//		EditText editName = (EditText) findViewById(R.id.edit_name);
//		String name = editName.getText().toString();
//		EditText editIngredients = (EditText) findViewById(R.id.edit_ingredient);
//		String ingredient = editIngredients.getText().toString();
//		EditText editAmount = (EditText) findViewById(R.id.edit_amount);
//		String amount = editAmount.getText().toString();
//		EditText editInstructions = (EditText) findViewById(R.id.edit_instructions);
//		String instructions = editInstructions.getText().toString();
//		
//		intent.putExtra(EXTRA_NAME, name);
//		intent.putExtra(EXTRA_AMOUNT, amount);
//		intent.putExtra(EXTRA_INGREDIENTS, ingredient);
//		intent.putExtra(EXTRA_INSTRUCTIONS, instructions);
//		startActivity(intent);
//	}
	
	public void writeToFile(View view) {
		try{
			//Sparar infon till en ny fil
			
			EditText editName = (EditText) findViewById(R.id.edit_name);
			String recipename = editName.getText().toString();
			EditText editAmount = (EditText) findViewById(R.id.edit_amount);
			String amount = editAmount.getText().toString();
			EditText editIngredient = (EditText) findViewById(R.id.edit_ingredient);
			String ingredient = editIngredient.getText().toString();
			EditText editInstructions = (EditText) findViewById(R.id.edit_instructions);
			String instructions = editInstructions.getText().toString();
			String filename = recipename.toLowerCase() + ".txt";
			
			String recipe = recipename + "\n\nIngredienser: \n" + amount + " " + SPINNER + " " + ingredient + "\n\nInstruktioner: \n" + instructions;
			
			FileOutputStream fOut = openFileOutput(filename, MODE_WORLD_READABLE);
			OutputStreamWriter osw = new OutputStreamWriter(fOut);
			
			osw.write(recipe);
			
			osw.flush();
			osw.close();
			
			//Endast f�r test: Skriver ut receptet
			
			FileInputStream fIn = openFileInput(filename);
			InputStreamReader isr = new InputStreamReader(fIn);
			
			char[] inputBuffer = new char[recipe.length()];
			
			isr.read(inputBuffer);
			
			String readString = new String(inputBuffer);
			boolean isTheSame = recipe.equals(readString);
			Log.i("File reading stuff", "success = " + isTheSame);
			
			TextView test = (TextView) findViewById(R.id.test);
			test.setText(readString);
			
		} catch (IOException ioe)
		{ioe.printStackTrace();}
	}
	
	private String readFromFile(String filename) {

		File testFile = new File("hittamig.txt");
    	String path = testFile.getAbsolutePath();
    	System.out.println(path);
    	System.out.println("Dir " + getFilesDir());
    	
		String ret = "";
		try {
			FileInputStream inputStream = openFileInput(filename);
			InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
			String recieveString = "";
			StringBuilder stringBuilder = new StringBuilder();
			
			while((recieveString = bufferedReader.readLine()) != null) {
				stringBuilder.append(recieveString);
				stringBuilder.append("\n");
			}
			
			inputStream.close();
			ret = stringBuilder.toString();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {}

		TextView test = (TextView) findViewById(R.id.test);
		test.setText(ret);

		return ret;
	}
}