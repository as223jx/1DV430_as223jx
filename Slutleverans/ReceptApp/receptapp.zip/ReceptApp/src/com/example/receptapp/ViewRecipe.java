package com.example.receptapp;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.os.Build;

public class ViewRecipe extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Intent intent = getIntent();
		String name = intent.getStringExtra(NewRecipeActivity.EXTRA_NAME);
		String ingredients = intent.getStringExtra(NewRecipeActivity.EXTRA_INGREDIENTS);
		String instructions = intent.getStringExtra(NewRecipeActivity.EXTRA_INSTRUCTIONS);
		String amount = intent.getStringExtra(NewRecipeActivity.EXTRA_AMOUNT);
		
		TextView viewName = new TextView(this);
		viewName.setText("Namn:\n" + name);
		
		TextView viewIngredients = new TextView(this);
		viewIngredients.setText("\nIngredienser:\n" + amount + " " + ingredients);
		
		TextView viewInstructions = new TextView(this);
		viewInstructions.setText("\nInstruktioner:\n" + instructions);
		
		LinearLayout viewLayout = new LinearLayout(this);
		viewLayout.setOrientation(LinearLayout.VERTICAL);
		viewLayout.addView(viewName);
		viewLayout.addView(viewIngredients);
		viewLayout.addView(viewInstructions);
		
		setContentView(viewLayout);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_recipe, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_view_recipe,
					container, false);
			return rootView;
		}
	}

}
